

-- use case 1 Gbm algorithm
SELECT  models_metrics.model_name, models_metrics.rmse, gbm_hpara.* FROM 
models_metrics INNER JOIN gbm_hpara ON
models_metrics.id = gbm_hpara.model_id
WHERE 
models_metrics.run_time = 300 AND models_metrics.algo_id = 'Algo_gbm'
ORDER BY models_metrics.rmse;


-- use case 1 Gbm algorithm
SELECT  models_metrics.model_name, models_metrics.rmse, glm_hpara.* FROM 
models_metrics INNER JOIN glm_hpara ON
models_metrics.id = glm_hpara.model_id
WHERE 
models_metrics.run_time = 300 AND models_metrics.algo_id = 'Algo_glm'
ORDER BY models_metrics.rmse;


-- use case 1 DRF algorithm
SELECT  models_metrics.model_name, models_metrics.rmse, drf_hpara.* FROM 
models_metrics INNER JOIN drf_hpara ON
models_metrics.id = drf_hpara.model_id
WHERE 
models_metrics.run_time = 300 AND models_metrics.algo_id = 'drf_drf'
ORDER BY models_metrics.rmse;


-- use case 1 naive_bayes algorithm
SELECT  models_metrics.model_name, models_metrics.rmse, naive_bayes_hpara.* FROM 
models_metrics INNER JOIN naive_bayes_hpara ON
models_metrics.id = naive_bayes_hpara.model_id
WHERE 
models_metrics.run_time = 300 AND models_metrics.algo_id = 'naive_bayes_hpara'
ORDER BY models_metrics.rmse;


-- use case 1 Gbm algorithm
SELECT  models_metrics.model_name, models_metrics.rmse, xg_boost_hpara.* FROM 
models_metrics INNER JOIN xg_boost_hpara ON
models_metrics.id = xg_boost_hpara.model_id
WHERE 
models_metrics.run_time = 300 AND models_metrics.algo_id = 'xgboost_gbm'
ORDER BY models_metrics.rmse;


SELECT algo_h2o.algo_name, COUNT(models_metrics.algo_id) AS no_of_models
FROM
models_metrics INNER JOIN algo_h2o ON 
models_metrics.algo_id = algo_h2o.algo_id
WHERE models_metrics.run_time = 500
GROUP BY algo_h2o.algo_id;

SELECT algo_h2o.algo_name, COUNT(models_metrics.algo_id) AS no_of_models
FROM
models_metrics INNER JOIN algo_h2o ON 
models_metrics.algo_id = algo_h2o.algo_id
WHERE models_metrics.run_time = 300
GROUP BY algo_h2o.algo_id;

SELECT algo_h2o.algo_name, COUNT(models_metrics.algo_id) AS no_of_models
FROM
models_metrics INNER JOIN algo_h2o ON 
models_metrics.algo_id = algo_h2o.algo_id
WHERE models_metrics.run_time = 700
GROUP BY algo_h2o.algo_id;

